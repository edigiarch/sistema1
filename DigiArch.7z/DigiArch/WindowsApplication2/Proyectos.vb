﻿Public Class Proyecto

    Private Sub CarpetasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CarpetasToolStripMenuItem.Click
        texto_seleccionado = ""
        Operador.ShowDialog()
    End Sub

    Private Sub BtnExaminar_Click(sender As Object, e As EventArgs) Handles BtnExaminar.Click
        Dim ruta As String
        FolderBrowserDialog1.ShowDialog()
        ruta = FolderBrowserDialog1.SelectedPath
        Txtruta.Text = ruta
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        Dim total As Integer
        'Buscar duplicado
        Try
            Conexxion.CN.Open()
            Consultar("SELECT COUNT(*) total FROM proyecto WHERE nombre_proyecto = '" & TxtNombre.Text & "' AND CarpetaProyecto = '" & new_ruta & "'")
            If oData.HasRows Then
                While oData.Read
                    total = oData.Item("total")
                End While
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
        If total > 0 Then
            MsgBox("Ya existe un proyecto con el nombre ingresado.")
        Else
            new_ruta = Txtruta.Text.Replace("\", "\\")
            Try
                Insertar("INSERT INTO proyecto values(null,'" & new_ruta & "', '" & TxtNombre.Text & "', now())")
                System.IO.Directory.CreateDirectory(Txtruta.Text & "\" & TxtNombre.Text)
                TxtNombre.Clear()
                Txtruta.Clear()
                texto_seleccionado = TxtNombre.Text
                Operador.ShowDialog()
            Catch ex As Exception
                Conexxion.CN.Close()
                MsgBox(ex.Message.ToString)
            End Try
        End If
    End Sub
    Private Sub BuscarProyecto()
        Try
            Conexxion.CN.Open()
            Consultar("SELECT CarpetaProyecto FROM proyecto")
            If oData.HasRows Then
                While oData.Read
                    ruta_principal = oData.Item("CarpetaProyecto")
                End While
                Txtruta.Clear()
                Txtruta.Text = ruta_principal
                new_ruta = ruta_principal.Replace("\", "\\")
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub


    Private Sub Proyecto_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        BuscarProyecto()
    End Sub
End Class