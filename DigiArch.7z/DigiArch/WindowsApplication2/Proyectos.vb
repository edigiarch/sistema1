﻿Imports MySql.Data.MySqlClient
Public Class Proyecto
    Private Sub CarpetasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CarpetasToolStripMenuItem.Click
        texto_seleccionado = ""
        Operador.ShowDialog()
    End Sub

    Private Sub BtnExaminar_Click(sender As Object, e As EventArgs) Handles BtnExaminar.Click
        Dim ruta As String
        FolderBrowserDialog1.ShowDialog()
        ruta = FolderBrowserDialog1.SelectedPath
        Txtruta.Text = ruta
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        Dim ruta As String
        Dim tamanio As Integer
        Dim total As Integer
        'Buscar duplicado
        Try
            Conexxion.CN.Open()
            Consultar("SELECT COUNT(*) total FROM proyecto WHERE nombre_proyecto = '" & TxtNombre.Text & "'")
            If oData.HasRows Then
                While oData.Read
                    total = oData.Item("total")
                End While
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
        Conexxion.CN.Close()
        If total > 0 Then
            MsgBox("Ya existe un proyecto con el nombre ingresado.")
        Else
            ruta = Txtruta.Text.ToString
            tamanio = ruta.Length
            Call slash(tamanio, ruta)
            ' MsgBox(new_ruta)
            Try
                Conexxion.CN.Open()
                Insertar("INSERT INTO proyecto values(null,'" & TxtNumP.Text & "', '" & TxtNombre.Text & "', now(), '" & new_ruta & "')")
                TxtNombre.Clear()
                TxtNumP.Clear()
                Txtruta.Clear()
                'TxtNombre.Focus()
                Conexxion.CN.Close()
                texto_seleccionado = TxtNombre.Text
                Operador.ShowDialog()
            Catch ex As Exception
                Conexxion.CN.Close()
                MsgBox(ex.Message.ToString)
            End Try
        End If
        Conexxion.CN.Close()

    End Sub

    Private Sub TotalPersonal(nombre As String)
        Try
            Conexxion.CN.Open()
            Consultar("SELECT COUNT(*) total FROM docentes WHERE fullname LIKE '%" & nombre & "%'")
            If oData.HasRows Then
                While oData.Read
                    'AllPersonal = oData.Item("total")
                End While
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
        Conexxion.CN.Close()
    End Sub

End Class