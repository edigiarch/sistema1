﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim HeaderDefinition1 As DevComponents.Tree.HeaderDefinition = New DevComponents.Tree.HeaderDefinition()
        Dim HeaderDefinition2 As DevComponents.Tree.HeaderDefinition = New DevComponents.Tree.HeaderDefinition()
        Dim HeaderDefinition3 As DevComponents.Tree.HeaderDefinition = New DevComponents.Tree.HeaderDefinition()
        Dim HeaderDefinition4 As DevComponents.Tree.HeaderDefinition = New DevComponents.Tree.HeaderDefinition()
        Me.LayoutSpacerItem1 = New DevComponents.DotNetBar.Layout.LayoutSpacerItem()
        Me.LayoutGroup1 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.LayoutGroup2 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.LayoutGroup3 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.LayoutGroup4 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.LayoutSpacerItem2 = New DevComponents.DotNetBar.Layout.LayoutSpacerItem()
        Me.LayoutGroup5 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.LayoutSpacerItem3 = New DevComponents.DotNetBar.Layout.LayoutSpacerItem()
        Me.LayoutGroup6 = New DevComponents.DotNetBar.Layout.LayoutGroup()
        Me.TreeGX1 = New DevComponents.Tree.TreeGX()
        Me.Node1 = New DevComponents.Tree.Node()
        Me.NodeConnector1 = New DevComponents.Tree.NodeConnector()
        Me.NodeConnector2 = New DevComponents.Tree.NodeConnector()
        Me.ElementStyle1 = New DevComponents.Tree.ElementStyle()
        Me.Node2 = New DevComponents.Tree.Node()
        Me.Node3 = New DevComponents.Tree.Node()
        Me.Node4 = New DevComponents.Tree.Node()
        Me.ElementStyle2 = New DevComponents.Tree.ElementStyle()
        Me.ElementStyle3 = New DevComponents.Tree.ElementStyle()
        Me.ElementStyle4 = New DevComponents.Tree.ElementStyle()
        CType(Me.TreeGX1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LayoutSpacerItem1
        '
        Me.LayoutSpacerItem1.Height = 32
        Me.LayoutSpacerItem1.Name = "LayoutSpacerItem1"
        Me.LayoutSpacerItem1.Width = 32
        '
        'LayoutGroup1
        '
        Me.LayoutGroup1.Height = 100
        Me.LayoutGroup1.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup1.Name = "LayoutGroup1"
        Me.LayoutGroup1.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup1.Width = 200
        '
        'LayoutGroup2
        '
        Me.LayoutGroup2.Height = 100
        Me.LayoutGroup2.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup2.Name = "LayoutGroup2"
        Me.LayoutGroup2.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup2.Width = 200
        '
        'LayoutGroup3
        '
        Me.LayoutGroup3.Height = 100
        Me.LayoutGroup3.Image = CType(resources.GetObject("LayoutGroup3.Image"), System.Drawing.Image)
        Me.LayoutGroup3.ImagePosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Right
        Me.LayoutGroup3.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup3.Name = "LayoutGroup3"
        Me.LayoutGroup3.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup3.Width = 200
        '
        'LayoutGroup4
        '
        Me.LayoutGroup4.Height = 100
        Me.LayoutGroup4.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup4.Name = "LayoutGroup4"
        Me.LayoutGroup4.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup4.Width = 200
        '
        'LayoutSpacerItem2
        '
        Me.LayoutSpacerItem2.Height = 32
        Me.LayoutSpacerItem2.Name = "LayoutSpacerItem2"
        Me.LayoutSpacerItem2.Width = 32
        '
        'LayoutGroup5
        '
        Me.LayoutGroup5.Height = 100
        Me.LayoutGroup5.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup5.Name = "LayoutGroup5"
        Me.LayoutGroup5.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup5.Width = 200
        '
        'LayoutSpacerItem3
        '
        Me.LayoutSpacerItem3.Height = 32
        Me.LayoutSpacerItem3.Name = "LayoutSpacerItem3"
        Me.LayoutSpacerItem3.Width = 32
        '
        'LayoutGroup6
        '
        Me.LayoutGroup6.Height = 100
        Me.LayoutGroup6.Image = CType(resources.GetObject("LayoutGroup6.Image"), System.Drawing.Image)
        Me.LayoutGroup6.ImagePosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Right
        Me.LayoutGroup6.MinSize = New System.Drawing.Size(120, 32)
        Me.LayoutGroup6.Name = "LayoutGroup6"
        Me.LayoutGroup6.TextPosition = DevComponents.DotNetBar.Layout.eLayoutPosition.Top
        Me.LayoutGroup6.Width = 200
        '
        'TreeGX1
        '
        Me.TreeGX1.AllowDrop = True
        Me.TreeGX1.CommandBackColorGradientAngle = 90
        Me.TreeGX1.CommandMouseOverBackColor2SchemePart = DevComponents.Tree.eColorSchemePart.ItemHotBackground2
        Me.TreeGX1.CommandMouseOverBackColorGradientAngle = 90
        Me.TreeGX1.ExpandLineColorSchemePart = DevComponents.Tree.eColorSchemePart.BarDockedBorder
        Me.TreeGX1.Headers.Add(HeaderDefinition1)
        Me.TreeGX1.Headers.Add(HeaderDefinition2)
        Me.TreeGX1.Headers.Add(HeaderDefinition3)
        Me.TreeGX1.Headers.Add(HeaderDefinition4)
        Me.TreeGX1.Location = New System.Drawing.Point(61, 177)
        Me.TreeGX1.Name = "TreeGX1"
        Me.TreeGX1.Nodes.AddRange(New DevComponents.Tree.Node() {Me.Node1, Me.Node2, Me.Node3, Me.Node4})
        Me.TreeGX1.NodesConnector = Me.NodeConnector2
        Me.TreeGX1.NodeStyle = Me.ElementStyle1
        Me.TreeGX1.PathSeparator = ";"
        Me.TreeGX1.RootConnector = Me.NodeConnector1
        Me.TreeGX1.Size = New System.Drawing.Size(197, 130)
        Me.TreeGX1.Styles.Add(Me.ElementStyle1)
        Me.TreeGX1.Styles.Add(Me.ElementStyle2)
        Me.TreeGX1.Styles.Add(Me.ElementStyle3)
        Me.TreeGX1.Styles.Add(Me.ElementStyle4)
        Me.TreeGX1.SuspendPaint = False
        Me.TreeGX1.TabIndex = 0
        Me.TreeGX1.Text = "TreeGX1"
        '
        'Node1
        '
        Me.Node1.Expanded = True
        Me.Node1.Name = "Node1"
        Me.Node1.Text = "Node1"
        '
        'NodeConnector1
        '
        Me.NodeConnector1.LineWidth = 5
        '
        'NodeConnector2
        '
        Me.NodeConnector2.LineWidth = 5
        '
        'ElementStyle1
        '
        Me.ElementStyle1.BackColor2SchemePart = DevComponents.Tree.eColorSchemePart.BarBackground2
        Me.ElementStyle1.BackColorGradientAngle = 90
        Me.ElementStyle1.BackColorSchemePart = DevComponents.Tree.eColorSchemePart.BarBackground
        Me.ElementStyle1.BorderBottom = DevComponents.Tree.eStyleBorderType.Solid
        Me.ElementStyle1.BorderBottomWidth = 1
        Me.ElementStyle1.BorderColorSchemePart = DevComponents.Tree.eColorSchemePart.BarDockedBorder
        Me.ElementStyle1.BorderLeft = DevComponents.Tree.eStyleBorderType.Solid
        Me.ElementStyle1.BorderLeftWidth = 1
        Me.ElementStyle1.BorderRight = DevComponents.Tree.eStyleBorderType.Solid
        Me.ElementStyle1.BorderRightWidth = 1
        Me.ElementStyle1.BorderTop = DevComponents.Tree.eStyleBorderType.Solid
        Me.ElementStyle1.BorderTopWidth = 1
        Me.ElementStyle1.CornerDiameter = 4
        Me.ElementStyle1.CornerType = DevComponents.Tree.eCornerType.Rounded
        Me.ElementStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElementStyle1.Name = "ElementStyle1"
        Me.ElementStyle1.PaddingBottom = 3
        Me.ElementStyle1.PaddingLeft = 3
        Me.ElementStyle1.PaddingRight = 3
        Me.ElementStyle1.PaddingTop = 3
        Me.ElementStyle1.TextColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
        '
        'Node2
        '
        Me.Node2.Name = "Node2"
        '
        'Node3
        '
        Me.Node3.Name = "Node3"
        '
        'Node4
        '
        Me.Node4.Name = "Node4"
        '
        'ElementStyle2
        '
        Me.ElementStyle2.Name = "ElementStyle2"
        '
        'ElementStyle3
        '
        Me.ElementStyle3.Name = "ElementStyle3"
        '
        'ElementStyle4
        '
        Me.ElementStyle4.Name = "ElementStyle4"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(651, 498)
        Me.Controls.Add(Me.TreeGX1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.TreeGX1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LayoutSpacerItem1 As DevComponents.DotNetBar.Layout.LayoutSpacerItem
    Friend WithEvents LayoutGroup1 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents LayoutGroup2 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents LayoutGroup3 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents LayoutGroup4 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents LayoutSpacerItem2 As DevComponents.DotNetBar.Layout.LayoutSpacerItem
    Friend WithEvents LayoutGroup5 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents LayoutSpacerItem3 As DevComponents.DotNetBar.Layout.LayoutSpacerItem
    Friend WithEvents LayoutGroup6 As DevComponents.DotNetBar.Layout.LayoutGroup
    Friend WithEvents TreeGX1 As DevComponents.Tree.TreeGX
    Friend WithEvents Node1 As DevComponents.Tree.Node
    Friend WithEvents Node2 As DevComponents.Tree.Node
    Friend WithEvents Node3 As DevComponents.Tree.Node
    Friend WithEvents Node4 As DevComponents.Tree.Node
    Friend WithEvents NodeConnector2 As DevComponents.Tree.NodeConnector
    Friend WithEvents ElementStyle1 As DevComponents.Tree.ElementStyle
    Friend WithEvents NodeConnector1 As DevComponents.Tree.NodeConnector
    Friend WithEvents ElementStyle2 As DevComponents.Tree.ElementStyle
    Friend WithEvents ElementStyle3 As DevComponents.Tree.ElementStyle
    Friend WithEvents ElementStyle4 As DevComponents.Tree.ElementStyle
End Class
