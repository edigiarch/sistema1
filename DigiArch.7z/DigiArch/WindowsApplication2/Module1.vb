﻿Imports MySql.Data.MySqlClient
Module Module1
    Public oData As MySqlDataReader
    Private server As String = "localhost"
    Private db As String = "digiarch"
    Private user As String = "root"
    Private pass As String = ""
    Public texto_seleccionado As String
    Public new_ruta As String

    Public Class Conexxion
        Public Shared CN As New MySqlConnection("Server=" & server & ";database=" & db & ";user =" & user & ";password =" & pass & ";")
    End Class
    Public Sub slash(tamanio As Integer, ruta As String)
        For i = 1 To tamanio Step 1
            If Microsoft.VisualBasic.Right(Microsoft.VisualBasic.Left(ruta, i), 1) = "\" Then
                new_ruta &= "\\"
            Else
                new_ruta &= Microsoft.VisualBasic.Right(Microsoft.VisualBasic.Left(ruta, i), 1)
            End If
        Next
    End Sub
    Public Sub Consultar(Query As String)
        Dim command = New MySqlCommand(Query, Conexxion.CN)
        oData = command.ExecuteReader()
    End Sub
    Public Sub ModificarDatos(Query As String)
        Dim cmd As New MySqlCommand(Query, Conexxion.CN)
        If cmd.CommandType = CommandType.Text Then
            cmd.ExecuteNonQuery()
            Conexxion.CN.Close()
            MsgBox("Datos modificados correctamente")
        Else
            Conexxion.CN.Close()
            MsgBox("Error al modificar datos")
        End If
    End Sub
    Public Sub Insertar(Query As String)
        Conexxion.CN.Open()
        Dim Command As New MySqlCommand(Query, Conexxion.CN)
        If Command.CommandType = CommandType.Text Then
            Command.ExecuteNonQuery()
            Conexxion.CN.Close()
            MsgBox("Datos insertados correctamente")
        Else
            Conexxion.CN.Close()
            MsgBox("Error al insertar datos")
        End If
    End Sub
End Module
