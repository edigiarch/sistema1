﻿Imports System.IO
Imports System.IO.FileInfo
Public Class Operador
    Dim x As Integer
    Dim y As Integer
    Dim i As Integer
    Dim ImagenX, PanelX, LabelX As String
    Dim xp, yp As Integer
    Dim id_proyecto, id_carpeta As Integer
    'Dim ruta_proyecto As String
    Dim Nombre_carpeta As String
    Dim TotalDP As Integer
    Dim DirecotorioPrincipal() As String
    Dim CarpetaProyecto As String
    Dim NombreProyecto As String
    Friend WithEvents pic As System.Windows.Forms.PictureBox
    Friend WithEvents pan As System.Windows.Forms.Panel
    Friend WithEvents lab As System.Windows.Forms.Label

    Public Sub crear()
        Dim ctrl As Control
        Dim total As Integer
        total = ListBox1.Items.Count
        For indice = 0 To total - 1
            ctrl = BuscaControl("Label" & indice, Panel1)
            If ctrl Is Nothing Then
                'creando el panel
                pan = New System.Windows.Forms.Panel
                pan.Width = 113
                pan.Height = 120
                'pan.BackColor = Color.Orange
                pan.Location = New Point(x + 5, y + 5)
                pan.Name = "Panel" & indice
                'escribiendo el nombre
                lab = New System.Windows.Forms.Label
                lab.Width = 113
                lab.Height = 15
                lab.Text = ListBox2.Items(indice)
                lab.TextAlign = ContentAlignment.MiddleCenter
                lab.ForeColor = Color.White
                lab.Location = New Point(x + 5, y + 110)
                lab.Name = "Label" & indice
                'creadon la imagen
                pic = New System.Windows.Forms.PictureBox
                pic.Width = 113
                pic.Height = 105
                pic.BackColor = Color.Red
                pic.BorderStyle = BorderStyle.FixedSingle
                pic.Location = New Point(x + 5, y + 5)
                pic.BackgroundImage = Image.FromFile(ListBox1.Items(indice))
                pic.BackgroundImageLayout = ImageLayout.Stretch
                pic.ContextMenuStrip = ContextMenuStrip1
                pic.Cursor = System.Windows.Forms.Cursors.Hand
                x = x + 125
                pic.Name = "Picture" & indice
                AddHandler pic.Click, AddressOf pic_Click
                'agregamos los controles
                Panel1.Controls.Add(pic)
                Panel1.Controls.Add(lab)
                Panel1.Controls.Add(pan)
                i += 1
                If i = 4 Then
                    y = y + 135
                    x = 0
                    i = 0
                End If
            Else

            End If
        Next
    End Sub

    Function BuscaControl(ByVal Nombre As String, ByVal Contenedor As Control) As Control
        Dim c As Control = Nothing
        For Each ctrl As Control In Contenedor.Controls
            If UCase(ctrl.Name) = UCase(Nombre) Then
                c = ctrl
                Exit For
            End If
        Next
        Return c
    End Function

    Private Sub pic_Click(sender As Object, e As EventArgs) Handles pic.Click
        Dim ctrl As Control
        Dim c As Integer = 0
        While True
            If CType(sender, Windows.Forms.PictureBox).Name = "Picture" & c Then
                'MsgBox("Picture" & c)
                ctrl = BuscaControl("Picture" & c, Panel1)
                xp = ctrl.Location.X
                yp = ctrl.Location.Y
                ImagenX = "Picture" & c
                PanelX = "Panel" & c
                LabelX = "Label" & c
                ListBox1.SelectedIndex = c
                ListBox2.SelectedIndex = c
                Exit While
            End If
            c = c + 1
        End While
    End Sub
    Private Sub BuscarIdProyecto()
        Dim textosql As String
        textosql = GroupBoxProyectos.Text.Replace("\", "\\")
        Try
            Conexxion.CN.Open()
            Consultar("SELECT * FROM proyecto WHERE nombre_proyecto = '" & NombreProyecto & "' AND CarpetaProyecto = '" & textosql & "'")
            If oData.HasRows Then
                While oData.Read
                    id_proyecto = oData.Item("idProyecto")
                End While
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub CrearCarpeta()
        Try
            Insertar("INSERT INTO carpetas VALUES(null,'" & TxtNombre.Text & "','" & id_proyecto & "','nulo')")
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        'Call BuscarIdProyecto()
        Call CrearCarpeta()
        System.IO.Directory.CreateDirectory(GroupBoxProyectos.Text & "\" & TreeViewFolder.SelectedNode.FullPath & "\" & TxtNombre.Text)
        TxtNombre.Clear()
        TreeViewFolder.Nodes.Clear()
        Call PopulateTreeView()
        TreeViewFolder.ExpandAll()
    End Sub

    Private Sub PopulateTreeView()
        TreeViewFolder.Nodes.Clear()
        For indice = 1 To TotalDP Step 1
            Dim rootNode As TreeNode
            Dim info As New DirectoryInfo(DirecotorioPrincipal(indice).ToString)
            If info.Exists Then
                rootNode = New TreeNode(info.Name)
                rootNode.Tag = info
                GetDirectories(info.GetDirectories(), rootNode)
                TreeViewFolder.Nodes.Add(rootNode)
            End If
        Next
    End Sub

    Private Sub GetDirectories(ByVal subDirs() As DirectoryInfo, ByVal nodeToAddTo As TreeNode)

        Dim aNode As TreeNode
        Dim subSubDirs() As DirectoryInfo
        Dim subDir As DirectoryInfo
        For Each subDir In subDirs
            aNode = New TreeNode(subDir.Name, 0, 0)
            aNode.Tag = subDir
            aNode.ImageKey = "Carpeta"
            subSubDirs = subDir.GetDirectories()
            If subSubDirs.Length <> 0 Then
                GetDirectories(subSubDirs, aNode)
            End If
            nodeToAddTo.Nodes.Add(aNode)
        Next subDir

    End Sub

    Private Sub treeViewFolder_NodeMouseClick(ByVal sender As Object, ByVal e As TreeNodeMouseClickEventArgs) Handles TreeViewFolder.NodeMouseClick
        Dim newSelected As TreeNode = e.Node
        ListView1.Items.Clear()
        Dim nodeDirInfo As DirectoryInfo =
        CType(newSelected.Tag, DirectoryInfo)
        Dim subItems() As ListViewItem.ListViewSubItem
        Dim item As ListViewItem = Nothing

        Dim dir As DirectoryInfo
        For Each dir In nodeDirInfo.GetDirectories()
            item = New ListViewItem(dir.Name, 0)
            subItems = New ListViewItem.ListViewSubItem() _
                {New ListViewItem.ListViewSubItem(item, "Directorio"),
                New ListViewItem.ListViewSubItem(item,
                dir.LastAccessTime.ToShortDateString())}

            item.SubItems.AddRange(subItems)
            ListView1.Items.Add(item)
        Next dir
        Dim file As FileInfo
        For Each file In nodeDirInfo.GetFiles()
            item = New ListViewItem(file.Name, 1)
            subItems = New ListViewItem.ListViewSubItem() _
                {New ListViewItem.ListViewSubItem(item, "Archivo"),
                New ListViewItem.ListViewSubItem(item,
                file.LastAccessTime.ToShortDateString())}

            item.SubItems.AddRange(subItems)
            ListView1.Items.Add(item)
        Next file

        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)

    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As EventArgs) Handles BtnRefresh.Click
        TreeViewFolder.Nodes.Clear()
        Call PopulateTreeView()
    End Sub

    Public Sub CargarImagen()
        On Error GoTo ErrorHandler
        With OpenFileDialog1
            .Filter = " Todos los Archivo (*.*) | *.*"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                ListBox1.Items.AddRange(.FileNames)
                ListBox2.Items.AddRange(.SafeFileNames)
            End If
        End With
        Exit Sub
ErrorHandler:
        MsgBox("Se ha Generado un Error" & Chr(13) & "No se pudo leer el archivo: " + OpenFileDialog1.SafeFileName, MsgBoxStyle.Information, "Aviso")
        Resume Next
    End Sub

    Private Sub Operador_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call QuitarDP()
        Call PopulateTreeView()
        Panel1.Invalidate()
        TreeViewFolder.ExpandAll()
        TreeViewFolder.Select()
    End Sub


    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BtnEliminar_Click(sender As Object, e As EventArgs) Handles BtnEliminar.Click
        EliminarToolStripMenuItem.PerformClick()
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        Call BuscarIdCarpeta()
        'MsgBox(id_carpeta & " " & id_proyecto)
        Call CopiarImagen()
        Call GuardarImagen()
        TreeViewFolder.ExpandAll()
    End Sub
    Private Sub BuscarIdCarpeta()
        Try
            Conexxion.CN.Open()
            Consultar("SELECT * FROM carpetas WHERE idProyecto = '" & id_proyecto & "'")
            If oData.HasRows Then
                While oData.Read
                    id_carpeta = oData.Item("idCarpeta")
                End While
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Private Sub GuardarImagen()
        Dim total As Integer
        Dim path1 As String = ""
        Dim peso, extension, nombre As String
        Dim fileDetail As IO.FileInfo
        total = ListBox2.Items.Count
        Nombre_carpeta = GroupBoxProyectos.Text & "\" & TreeViewFolder.SelectedNode.FullPath & "\"
        Try
            new_ruta = ""
            new_ruta = Nombre_carpeta.Replace("\", "\\")
            For x = 0 To total - 1 Step 1
                peso = getTamFile(ListBox1.Items(0))
                fileDetail = My.Computer.FileSystem.GetFileInfo(ListBox2.Items(x))
                nombre = Path.GetFileNameWithoutExtension(ListBox2.Items(x))
                extension = fileDetail.Extension
                Insertar("INSERT INTO documentos VALUES(null,'" & new_ruta & "','" & id_carpeta & "','" & id_proyecto & "','" & nombre & "','" & peso & "','" & extension & "',now(),now(),null)")
            Next

        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
    Public Function getTamFile(ByVal path As String) As String
        Dim fi As New FileInfo(path)
        If fi.Exists Then
            If (fi.Length / 1024) > 1024 Then
                Return Math.Round(((fi.Length / 1024) / 1024), 2).ToString() & " Mb"
            Else
                Return Math.Round((fi.Length / 1024), 2).ToString() & " Kb"
            End If
        Else
            Return String.Empty
        End If
    End Function

    Private Sub TreeViewFolder_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles TreeViewFolder.AfterSelect
        Dim texto As String = TreeViewFolder.SelectedNode.FullPath
        Dim FirstCharacter As Integer = texto.IndexOf("\")
        If FirstCharacter = -1 Then
            NombreProyecto = TreeViewFolder.SelectedNode.FullPath
        Else
            Dim respuesta As String = texto.Substring(0, texto.IndexOf("\"))
            NombreProyecto = respuesta
        End If
        Call BuscarIdProyecto()
        Call BuscarIdCarpeta()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Panel1.Controls.Clear()
        If ListView1.SelectedItems.Count > 0 Then
            Panel1.BackgroundImage = Image.FromFile(GroupBoxProyectos.Text & "\" & TreeViewFolder.SelectedNode.FullPath & "\" & ListView1.SelectedItems(0).Text)
        End If

        'MsgBox(ListView1.SelectedItems(0).ToString)
    End Sub

    Public Sub CopiarImagen()
        Dim total As Integer
        total = ListBox1.Items.Count
        Nombre_carpeta = TreeViewFolder.SelectedNode.FullPath
        For x = 0 To total - 1 Step 1
            Dim origen As String = ListBox1.Items(x)
            Dim destino As String = GroupBoxProyectos.Text & "\" & Nombre_carpeta & "\" & ListBox2.Items(x)
            System.IO.File.Copy(origen, destino, True)
        Next
        MsgBox("Datos guardados con Exito")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles BtnCargar.Click

        'Panel1.BackgroundImage.RemovePropertyItem(Image)
        Panel1.BackColor = Color.Black
        Call CargarImagen()
        Call crear()
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarToolStripMenuItem.Click
        If ListBox1.SelectedIndex = -1 Then
            MsgBox("Seleccione un elemento")
        Else
            ListBox1.Items.RemoveAt(ListBox1.SelectedIndex)
            ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)
            Panel1.Controls.RemoveByKey(ImagenX)
            Panel1.Controls.RemoveByKey(PanelX)
            Panel1.Controls.RemoveByKey(LabelX)
            Dim t As Integer
            t = ListBox1.Items.Count
            If t = 0 Or PanelX = "Panel" & t Then
            Else
                Dim ctrl As Control
                ctrl = BuscaControl("Panel" & ListBox1.Items.Count, Panel1)
                ctrl.Location = New System.Drawing.Point(xp, yp)
                ctrl = BuscaControl("Picture" & ListBox1.Items.Count, Panel1)
                ctrl.Location = New System.Drawing.Point(xp, yp)
                ctrl = BuscaControl("Label" & ListBox1.Items.Count, Panel1)
                ctrl.Location = New System.Drawing.Point(xp + 5, yp + 110)
                ctrl = BuscaControl("Panel" & ListBox1.Items.Count, Panel1)
                ctrl.Name = PanelX
                ctrl = BuscaControl("Picture" & ListBox1.Items.Count, Panel1)
                ctrl.Name = ImagenX
                ctrl = BuscaControl("Label" & ListBox1.Items.Count, Panel1)
                ctrl.Name = LabelX
            End If
        End If

    End Sub
    Private Sub QuitarDP()
        Dim punto As Integer = 1
        Try
            Conexxion.CN.Open()
            Consultar("SELECT (SELECT COUNT(*) FROM proyecto)total, CONCAT(CarpetaProyecto,'\\',nombre_proyecto) ruta,CarpetaProyecto principal FROM proyecto")
            If oData.HasRows Then
                oData.Read()
                TotalDP = oData.Item("total")
                ReDim DirecotorioPrincipal(TotalDP)
                DirecotorioPrincipal(punto) = oData.Item("ruta")
                GroupBoxProyectos.Text = oData.Item("principal")
                While oData.Read
                    punto += 1
                    DirecotorioPrincipal(punto) = oData.Item("ruta")
                End While
            End If
            Conexxion.CN.Close()
        Catch ex As Exception
            Conexxion.CN.Close()
            MsgBox(ex.Message.ToString)
        End Try
    End Sub

    Private Sub TreeViewFolder_AfterExpand(sender As Object, e As TreeViewEventArgs) Handles TreeViewFolder.AfterExpand

    End Sub
End Class
